#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QString>
#include <QProcess>
#include <QLabel>
#include <QRandomGenerator64>
#include <QLineEdit>
#include <QMessageBox>
#include "DisButton.h"

QT_BEGIN_NAMESPACE
namespace Ui {
class Widget;
}
QT_END_NAMESPACE

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();

private slots:
    void mode1();
    void mode2();
    void startpage();
    void endpage();

private:
    Ui::Widget *ui;
    QTimer *mainTimer, *levelTimer, *secondTimer;
    QLabel *left, *right, *middle;
    DisButton *btn[30];
    QPushButton *btn1, *btn2, *replay, *quit, *menu, *start;
    std::random_device rand;
    QLineEdit *numLine;
    int id, level, life, cnt, time, op;
};
#endif // WIDGET_H
