#ifndef DISBUTTON_H
#define DISBUTTON_H

#include <QPushButton>
#include <QTimer>
#include <QRandomGenerator64>
#include <QObject>

class DisButton : public QPushButton {
    Q_OBJECT
public:
    QTimer lifeTimer;
    DisButton(int seed);
    ~DisButton();
    void Start1();
    void Start2();
    void update();
    std::pair<int, int > getpos();
    void changepos(std::pair<int, int>);
private slots:
    void ButtonShrink();
private:
    int size;
    std::pair<int, int> pos;
    QRandomGenerator64 *rand;
    QTimer *timer;
};

#endif // DISBUTTON_H
