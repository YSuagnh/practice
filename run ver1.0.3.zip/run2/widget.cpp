#include "widget.h"
#include "./ui_widget.h"
#include <QDebug>

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);
    this->setWindowTitle("Shoot!");
    this->setFixedSize(600, 600);
    ison = 0;

    rec1 = new QString("NULL"); rec2 = new QString("NULL");
    hits1 = hits2 = miss1 = miss2 = 0;
    RECORD = new QFile(QString("%1/record.txt").arg(QDir::currentPath()));
    RECORD -> open(QIODevice::ReadWrite);
    if(RECORD -> isOpen()) {
        QTextStream *in = new QTextStream(RECORD);
        hits1 = in -> readLine().toInt();
        miss1 = in -> readLine().toInt();
        *rec1 = in -> readLine();
        hits2 = in -> readLine().toInt();
        miss2 = in -> readLine().toInt();
        *rec2 = in -> readLine();
        delete in;
    } else qDebug() << 1;
    RECORD -> close();

    left = new QLabel(this), right = new QLabel(this), middle = new QLabel(this);
    left -> setFixedSize(50, 30), left -> move(5, 5);
    right -> setFixedSize(50, 30), right -> move(545, 5);
    middle -> setFixedSize(100, 30), middle -> move(260, 5);

    for(int i = 0; i < 30; ++i) {
        btn[i] = new DisButton(rand()), btn[i] -> setParent(this);
        connect(&btn[i] -> lifeTimer, &QTimer::timeout, [this](){
            right -> setText("Life " + QString::number(--life));
            if(!life) endpage();
        });
        connect(btn[i], &QPushButton::clicked, [this](){
            middle -> setText(QString::number(++cnt) + " hits " + QString::number(miss) + " miss");
            usp -> play();
        });
    }

    usp = new QSoundEffect(this);
    QString fileusp = QString("%1/usp.wav").arg(QDir::currentPath());
    usp -> setSource(QUrl::fromLocalFile(fileusp));
    usp -> setVolume(4.0);

    mainTimer = new QTimer;
    connect(mainTimer, &QTimer::timeout, [this](){
        btn[id]->Start1();
        btn[id++] -> lifeTimer.start(80 * 50 + 10);
        id %= 30;
    });

    levelTimer = new QTimer;
    connect(levelTimer, &QTimer::timeout, [this]() {
        ++level, life = 5;
        mainTimer -> start(650 - level * 50);
        left -> setText("Level " + QString::number(level));
        right -> setText("Life " + QString::number((life)));
    });
    secondTimer = new QTimer;
    connect(secondTimer, &QTimer::timeout, [this](){
        right -> setText("time " + QString::number(--time));
        if(!time) endpage();
    });

    btn1 = new QPushButton(this), btn2 = new QPushButton(this), record = new QPushButton(this);
    btn1 -> setFixedSize(200, 100), btn2 -> setFixedSize(200, 100), record -> setFixedSize(200, 100);
    btn1 -> move(200, 75), btn2 -> move(200, 250), record -> move(200, 425);
    btn1 -> setText("Mode 1"), btn2 -> setText("Mode 2"), record -> setText("Record");

    connect(btn1, &QPushButton::clicked, [this](){
        btn1 -> hide(), btn2 -> hide(), record -> hide(), mode1();
    });
    connect(btn2, &QPushButton::clicked, [this](){
        btn1 -> hide(), btn2 -> hide(), record -> hide(), mode2();
    });
    connect(record, &QPushButton::clicked, [this](){
        QString str1 = "Mode1 : " + QString::number(hits1) + " hits " + QString::number(miss1) + " miss " + *rec1;
        QString str2 = "Mode2 : " + QString::number(hits2) + " hits " + QString::number(miss2) + " miss " + *rec2;
        QMessageBox::information(this, "Records", str1 + "\n" + str2);
    });

    tips = new QLabel(this);
    tips -> setFixedSize(90, 30);
    tips -> move(185, 250);

    numLine = new QLineEdit(this);
    numLine -> setFixedSize(0, 0);
    numLine -> move(275, 250);
    connect(numLine, &QLineEdit::returnPressed, [this]() {start -> click(); });

    start = new QPushButton(this), replay = new QPushButton(this);
    menu = new QPushButton(this), quit = new QPushButton(this);

    start -> hide(), quit -> hide(), replay -> hide(), menu -> hide();
    start -> move(320, 300), start -> setFixedSize(100, 50), start -> setText("Start");
    connect(start, &QPushButton::clicked, [this]() {
        int n = numLine -> text().toInt();
        if(!n)
            QMessageBox::information(this, "Error!", "请输入1~30内的阿拉伯数字");
        else {
            numLine -> setFixedSize(0, 0);
            tips -> setText("");
            start -> hide();
            for(int i = 0; i < n; ++i)
                btn[i] -> Start2();
            secondTimer -> start(1000);
        }
    });

    replay -> move(37, 350), replay -> setFixedSize(150, 100), replay -> setText("Replay");
    connect(replay, &QPushButton::clicked, [this]() {
        replay -> hide(), menu -> hide(), quit -> hide();
        if(op == 1) mode1();
        else mode2();
    });

    menu -> move(224, 350), menu -> setFixedSize(150, 100), menu -> setText("Menu");
    connect(menu, &QPushButton::clicked, [this]() {
        replay -> hide(), menu -> hide(), quit -> hide();
        for(int i = 0; i < 30; ++i) {
            btn[i] -> disconnect();
            connect(btn[i], &QPushButton::clicked, [this](){
                middle -> setText(QString::number(++cnt) + " hits " + QString::number(miss) + " miss");
                usp -> play();
            });
        }
        startpage();
    });

    quit -> move(411, 350), quit -> setFixedSize(150, 100), quit -> setText("Quit");
    connect(quit, &QPushButton::clicked, [this]() { this -> close(); });

    startpage();
}

Widget::~Widget()
{
    updrecord();
    delete ui;
    delete mainTimer;
    delete levelTimer;
    delete secondTimer;
    delete quit;
    delete replay;
    delete menu;
    delete start;
    delete btn1;
    delete btn2;
    delete numLine;
    delete tips;
    delete RECORD;
    delete record;
    delete usp;
    delete rec1;
    delete rec2;
    for(int i = 0; i < 30; ++i)
        delete btn[i];
}

void Widget::startpage() {
    btn1 -> show(), btn2 -> show(), record -> show();
}

void Widget::mode1() {
    ison = 1, miss = 0;
    op = 1, cnt = 0, id = 0, life = 5, level = 1;
    left -> setText("Level 1");
    right -> setText("Life 5");
    middle -> setText("0 hits 0 miss");
    mainTimer -> start(600);
    levelTimer -> start(15000);
}

void Widget::mode2() {
    ison = 1, miss = 0;
    op = 2, cnt = 0, time = 60;
    numLine -> setFixedSize(50, 30);
    tips -> setText("请输入球的个数");
    start -> show();
    left -> setText("");
    middle -> setText("0 hits 0 miss");
    right -> setText("time 60");
}

void Widget::endpage() {
    ison = 0;
    mainTimer -> stop(), levelTimer -> stop(), secondTimer -> stop();
    for(int i = 0; i < 30; ++i) btn[i] -> stop();
    if((op == 1) && (cnt > hits1 || (cnt == hits1 && miss < miss1))) {
        hits1 = cnt, miss1 = miss, *rec1 = QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss");
        QString str = "Congratulation!!!\nYou have reached " + QString::number(cnt) + " hits";
        QMessageBox::information(this, "A New Record！", str);
    } else if((op == 2) && (cnt > hits2 || (cnt == hits2 && miss < miss2))) {
        hits2 = cnt, miss2 = miss, *rec2 = QDateTime::currentDateTime().toString("yyyy_MM-dd hh:mm:ss");
        QString str = "Congratulation!!!\nYou have reached " + QString::number(cnt) + " hits";
        QMessageBox::information(this, "A New Record！", str);
    }
    menu -> show(), quit -> show(), replay -> show();
}

void Widget::mousePressEvent(QMouseEvent *ev) {
    if(ev -> button() == Qt::LeftButton && ison) usp -> play(), ++miss;
    middle -> setText(QString::number(cnt) + " hits " + QString::number(miss) + " miss");
}

void Widget::updrecord() {
    RECORD -> open(QIODevice::WriteOnly);
    QTextStream *in = new QTextStream(RECORD);
    *in << hits1 << Qt::endl << miss1 << Qt::endl << *rec1 << Qt::endl;
    *in << hits2 << Qt::endl << miss2 << Qt::endl << *rec2 << Qt::endl;
    delete in;
}
