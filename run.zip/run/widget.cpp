#include "widget.h"
#include "./ui_widget.h"
#include <QDebug>

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);
    this->setWindowTitle("Shoot!");
    this->setFixedSize(600, 600);

    left = new QLabel(this), right = new QLabel(this), middle = new QLabel(this);
    left -> setFixedSize(50, 30), left -> move(5, 5);
    right -> setFixedSize(50, 30), right -> move(545, 5);
    middle -> setFixedSize(50, 30), middle -> move(280, 5);

    for(int i = 0; i < 30; ++i) {
        btn[i] = new DisButton(rand()), btn[i] -> setParent(this);
        connect(&btn[i] -> lifeTimer, &QTimer::timeout, [this](){
            right -> setText("Life " + QString::number(--life));
            if(!life) endpage();
        });
        connect(btn[i], &QPushButton::clicked, [this](){
            middle -> setText(QString::number(++cnt) + " hits"); });
    }

    mainTimer = new QTimer;
    connect(mainTimer, &QTimer::timeout, [this](){
        btn[id]->Start1();
        btn[id++] -> lifeTimer.start(80 * 50 + 10);
        id %= 30;
    });

    levelTimer = new QTimer;
    connect(levelTimer, &QTimer::timeout, [this]() {
        ++level, life = 5;
        mainTimer -> start(650 - level * 50);
        left -> setText("Level " + QString::number(level));
    });
    secondTimer = new QTimer;
    connect(secondTimer, &QTimer::timeout, [this](){
        right -> setText("time " + QString::number(--time));
        if(!time) endpage();
    });

    btn1 = new QPushButton(this), btn2 = new QPushButton(this);
    btn1 -> setParent(this), btn2 -> setParent(this);
    btn1 -> setFixedSize(200, 100), btn2 -> setFixedSize(200, 100);
    btn1 -> move(200, 100), btn2 -> move(200, 300);
    btn1 -> setText("Mode 1"), btn2 -> setText("Mode 2");

    connect(btn1, &QPushButton::clicked, [this](){
        btn1 -> hide(), btn2 -> hide(), mode1();
    });
    connect(btn2, &QPushButton::clicked, [this](){
        btn1 -> hide(), btn2 -> hide(), mode2();
    });

    numLine = new QLineEdit(this);
    numLine -> setParent(this);
    numLine -> setFixedSize(0, 0);
    numLine -> move(275, 250);
    connect(numLine, &QLineEdit::returnPressed, [this]() {start -> click(); });

    start = new QPushButton(this), replay = new QPushButton(this);
    menu = new QPushButton(this), quit = new QPushButton(this);

    start -> hide(), quit -> hide(), replay -> hide(), menu -> hide();
    start -> move(320, 300), start -> setFixedSize(100, 50), start -> setText("Start");
    connect(start, &QPushButton::clicked, [this]() {
        int n = numLine -> text().toInt();
        if(!n)
            QMessageBox::information(this, "Error!", "请输入1~30内的阿拉伯数字");
        else {
            numLine -> setFixedSize(0, 0);
            start -> hide();
            for(int i = 0; i < n; ++i)
                btn[i] -> Start2();
            secondTimer -> start(1000);
        }
    });

    replay -> move(37, 350), replay -> setFixedSize(150, 100), replay -> setText("Replay");
    connect(replay, &QPushButton::clicked, [this]() {
        replay -> hide(), menu -> hide(), quit -> hide();
        if(op == 1) mode1();
        else mode2();
    });

    menu -> move(224, 350), menu -> setFixedSize(150, 100), menu -> setText("Menu");
    connect(menu, &QPushButton::clicked, [this]() {
        replay -> hide(), menu -> hide(), quit -> hide();
        startpage();
    });

    quit -> move(411, 350), quit -> setFixedSize(150, 100), quit -> setText("Quit");
    connect(quit, &QPushButton::clicked, [this]() { this -> close(); });

    startpage();
}

Widget::~Widget()
{
    delete ui;
    delete mainTimer;
    delete levelTimer;
    delete secondTimer;
    delete quit;
    delete replay;
    delete menu;
    delete start;
    delete btn1;
    delete btn2;
    delete numLine;
    for(int i = 0; i < 30; ++i)
        delete btn[i];
}

void Widget::startpage() {
    btn1 -> show(), btn2 -> show();
}

void Widget::mode1() {
    op = 1, cnt = 0, id = 0, life = 5, level = 1;
    left -> setText("Level 1");
    right -> setText("Life 5");
    middle -> setText("0 hits");
    mainTimer -> start(600);
    levelTimer -> start(15000);
}

void Widget::mode2() {
    op = 2, cnt = 0, time = 60;
    numLine -> setFixedSize(50, 30);
    start -> show();
    middle -> setText("0 hits");
    right -> setText("time 60");
}

void Widget::endpage() {
    mainTimer -> stop(), levelTimer -> stop(), secondTimer -> stop();
    for(int i = 0; i < 30; ++i)
        btn[i] -> hide(), btn[i] -> lifeTimer.stop();
    menu -> show(), quit -> show(), replay -> show();
}

