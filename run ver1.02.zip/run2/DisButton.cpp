#include "DisButton.h"
#include <QDebug>

DisButton::DisButton(int seed) : QPushButton() {
    lifeTimer.setSingleShot(1);
    this -> hide();
    this -> setStyleSheet("background-color: red");
    rand = new QRandomGenerator64(seed);
    timer = new QTimer;
    connect(timer, &QTimer::timeout, this, &DisButton::ButtonShrink);
}

void DisButton::update() {
    this -> setFixedSize(size, size);
    this -> move(pos.first, pos.second);
    this -> setMask(QRegion(0, 0, size, size, QRegion::Ellipse));
}

void DisButton::stop() { this -> hide(); lifeTimer.stop(); timer -> stop(); }

void DisButton::Start1() {
    connect(this, &QPushButton::clicked, this, &DisButton::stop);
    size = 50;
    pos = std::make_pair((*rand)() % 550, (*rand)() % 550);
    update(), this -> show(), timer -> start(80);
}

void DisButton::Start2() {
    connect(this, &QPushButton::clicked, [this]() {
        pos = std::make_pair((*rand)() % 550, (*rand)() % 550), update(); });
    size = 50;
    pos = std::make_pair((*rand)() % 550, (*rand)() % 550);
    update(), this -> show();
}

DisButton::~DisButton(){
    delete timer;
}

void DisButton::ButtonShrink() {
    --size;
    if(!size) this -> hide(), timer -> stop();
    if((size & 1) == 0) pos.first++, pos.second++;
    update();
}
