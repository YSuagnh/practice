#include "Transform.h"

Transform::Transform() {
    a[0][0] = a[1][1] = a[2][2] = qreal(1);
}
Transform::Transform(qreal x, qreal y) {
    Transform a, b;
    a[1][1] = cos(x), a[1][2] = -sin(x);
    a[2][1] = sin(x), a[2][2] = cos(x);
    b[0][0] = cos(y), b[0][2] = sin(y);
    b[2][0] = -sin(y), b[2][2] = cos(y);
    *this = a * b;
}

qreal* Transform::operator[](const int &x) { return a[x]; }
void Transform::init() {
    for(int i = 0; i < 3; ++i) for(int j = 0; j < 3; ++j)
            a[i][j] = 0;
    a[0][0] = a[1][1] = a[2][2] = 1;
}
