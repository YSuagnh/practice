#include "DisButton.h"
#include <QDebug>

DisButton::DisButton(int seed) : QPushButton() {
    lifeTimer.setSingleShot(1);
    this -> hide();
    this -> setStyleSheet("background-color: red");
    rand = new QRandomGenerator64(seed);
    timer = new QTimer;
    connect(timer, &QTimer::timeout, this, &DisButton::ButtonShrink);
}

void DisButton::update() {
    this -> setFixedSize(size, size);
    this -> move(tx, ty);
    this -> setMask(QRegion(0, 0, size, size, QRegion::Ellipse));
}

void DisButton::stop() { this -> hide(); lifeTimer.stop(); timer -> stop(); cnt = 0; }

void DisButton::Start1() {
    connect(this, &QPushButton::clicked, this, &DisButton::stop);
    size = 50, cnt = 0;
    tx = posx = (*rand)() % 550 + 50, ty = posy = (*rand)() % 550 + 50;
    update(), this -> show(), timer -> start(10);
}

void DisButton::Start2() {
    connect(this, &QPushButton::clicked, [this]() {
        tx = posx = (*rand)() % 550 + 50, ty = posy = (*rand)() % 550 + 50, update(), timer -> start(10); });
    size = 50, cnt = 0;
    tx = posx = (*rand)() % 550 + 50, ty = posy = (*rand)() % 550 + 50;
    timer -> start(10), update(), this -> show();
}

DisButton::~DisButton(){
    delete timer;
}

void DisButton::ButtonShrink() {
    if(++cnt != 8) return update();
    if(op == 1) --size, cnt = 0;
    if(!size) this -> hide(), timer -> stop();
    if((size & 1) == 0) posx++, posy++;
    update();
}

QPointF DisButton::getpos() {
    return QPointF(qreal(size) / 2 + qreal(posx), qreal(size) / 2 + qreal(posy));
}

void DisButton::changepos(QPointF pos) {
    tx = round(pos.rx() - qreal(size) / 2), ty = round(pos.ry() - qreal(size) / 2);
}

void DisButton::setop(int x) { op = x; }
