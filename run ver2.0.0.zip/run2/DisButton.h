#ifndef DISBUTTON_H
#define DISBUTTON_H

#include <QPushButton>
#include <QTimer>
#include <QRandomGenerator64>
#include <QObject>
#include <QSoundEffect>

class DisButton : public QPushButton {
    Q_OBJECT
public:
    QTimer lifeTimer;
    DisButton(int seed);
    ~DisButton();
    void Start1();
    void Start2();
    void update();
    QPointF getpos();
    void changepos(QPointF);
    void stop();
    void setop(int x);
private slots:
    void ButtonShrink();
private:
    int size, posx, posy, tx, ty, cnt, op;
    QRandomGenerator64 *rand;
    QTimer *timer;
};

#endif // DISBUTTON_H
