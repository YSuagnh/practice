#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QString>
#include <QProcess>
#include <QLabel>
#include <QRandomGenerator64>
#include <QLineEdit>
#include <QMessageBox>
#include <QSoundEffect>
#include <QFile>
#include <QMouseEvent>
#include <QDir>
#include <QGraphicsScene>
#include <QGraphicsView>
#include <QGraphicsItem>
#include <QPainter>
#include <cmath>
#include "DisButton.h"
#include "Transform.h"

QT_BEGIN_NAMESPACE
namespace Ui {
class Widget;
}
QT_END_NAMESPACE

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();

protected:
    void paintEvent(QPaintEvent *);
    void mousePressEvent(QMouseEvent *ev);

private slots:
    void mode1();
    void mode2();
    void startpage();
    void endpage();
    void updrecord();

private:
    Ui::Widget *ui;
    QTimer *mainTimer, *levelTimer, *secondTimer, *mouseTimer;
    QLabel *left, *right, *middle, *tips;
    DisButton *btn[30];
    QPushButton *btn1, *btn2, *record, *replay, *quit, *menu, *start;
    std::random_device rand;
    QLineEdit *numLine;
    QSoundEffect *usp;
    QString *rec1, *rec2;
    QFile *RECORD;
    int id, level, life, cnt, time, op, ison, miss, hits1, hits2, miss1, miss2;
    QPointF rect[4], edge[4], pos1[60], pos2[60];
    QPainter *poly;
    Transform trans;
};
#endif // WIDGET_H
