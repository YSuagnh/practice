#ifndef TRANSFORM_H
#define TRANSFORM_H

#include <QPointF>
#include <QWidget>
#include <cmath>

class Transform {
private :
    qreal a[3][3];
public :
    Transform();
    Transform(qreal x, qreal y);
    qreal* operator [](const int &x);
    friend Transform operator * (const Transform &x, const Transform &y)  {
        Transform c; memset(c.a, 0, sizeof c.a);
        for(int k = 0; k < 3; ++k) for(int i = 0; i < 3; ++i)
                for(int j = 0; j < 3; ++j) c[i][j] += x.a[i][k] * y.a[k][j];
        return c;
    }
    friend QPointF operator * (const Transform &x, const QPointF &y) {
        qreal b[3] = { y.x() - 500, y.y() - 350, 1000 };
        qreal c[3] = { 0, 0, 0 };
        for(int k = 0; k < 3; ++k) for(int i = 0; i < 3; ++i)
            c[i] += x.a[i][k] * b[k];
        c[0] += 500, c[1] += 350;
        return QPointF(c[0], c[1]);
    }
    void init();
};

#endif // TRANSFORM_H
